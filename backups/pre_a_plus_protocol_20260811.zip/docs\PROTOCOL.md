# Experimental Protocol

## Main setting

- Static, calibrated sparse-view reconstruction.
- Context is 2 or 4 RGB images; target RGB is withheld at inference.
- Target queries use known intrinsics and camera-to-world matrices.
- State bounds are computed from training-visible scene geometry only and fixed before evaluation.
- Main outputs are metric ray depth, world normal, world point map, and visibility. RGB is
  auxiliary and is reported separately.

## Measurement-complete claim

Define a training measurement set `M_train` and an evaluation set `M_eval`. A measurement
generalization matrix reports every pair. The key row trains the same fixed state with RGB/depth
and evaluates normal, point, and visibility without adding a target-specific head. Report the
held-out gap against a seen measurement and the corresponding controls.

The primary controls are:

1. `fixed`: explicit state plus parameter-free renderer.
2. `learned_heads`: same context encoder/state capacity, separate learned per-measurement heads.
3. `free_decoder`: same state features plus query origin/direction and a shared learned decoder.

External references such as SRT/OSRT, pixelNeRF, pixelSplat, MVSplat, DUSt3R, MASt3R, VGGT, and
per-scene 3DGS must be rerun or evaluated under exactly the same split, context count, camera
inputs, image resolution, query frames, and metric implementation. Original paper numbers are
not directly comparable to this protocol.

## Metrics

- RGB: PSNR, SSIM, optional LPIPS.
- Depth: AbsRel, RMSE, delta-1.
- Normal: mean angular error and 5/11.25/22.5 degree accuracy.
- Point map: symmetric Chamfer and F-score at 0.05 m (also report the threshold in meters).
- Visibility: IoU and F1.

Each metric must include valid-pixel or valid-point counts. Missing modalities are not silently
treated as zeros.

## Mechanism diagnostics

- Cross-context consistency: compare predictions from two context subsets on identical queries.
- Query permutation: permute target camera order and require output equivariance.
- Intervention specificity: alter density or color fields separately and measure intended versus
  cross-task changes.
- No-bypass audit: fixed renderer parameter count is zero and model forward exposes no target
  labels.
- Uncertainty calibration: bin predicted variance and compare coverage/error when uncertainty is
  enabled.

These diagnostics establish inspectable mechanisms; they do not make arbitrary latent channels
human-interpretable.

## Leakage controls

Do not choose context frames after looking at target RGB/depth. Keep scenes disjoint across train,
validation, and test. Do not use target depth to compute scene bounds. Report per-scene and pooled
metrics, frame timing, state voxel resolution, number of ray samples, and peak GPU memory.
