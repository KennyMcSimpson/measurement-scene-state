"""Strict experiment configuration loading and validation."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

import yaml

from mcss.model.system import ModelConfig

DatasetName = Literal["synthetic", "manifest", "replica", "hypersim"]


@dataclass(frozen=True)
class DatasetConfig:
    name: DatasetName
    root: str | None
    image_size: tuple[int, int]
    context_views: int
    target_views: int
    length: int = 64
    sample_stride: int = 1


@dataclass(frozen=True)
class TrainingConfig:
    output_dir: str
    batch_size: int
    learning_rate: float
    max_steps: int
    num_workers: int
    amp: bool
    log_every: int
    checkpoint_every: int
    measurements: tuple[str, ...]
    gradient_accumulation: int = 1
    weight_decay: float = 0.0
    resume: str | None = None


@dataclass(frozen=True)
class ExperimentConfig:
    seed: int
    device: str
    dataset: DatasetConfig
    model: ModelConfig
    training: TrainingConfig


def load_config(path: str | Path) -> ExperimentConfig:
    config_path = Path(path)
    try:
        raw = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    except yaml.YAMLError as error:
        raise ValueError(f"invalid YAML in {config_path}") from error
    if not isinstance(raw, dict):
        raise ValueError("config root must be a mapping")
    _reject_unknown(raw, {"seed", "device", "dataset", "model", "training"}, "config")
    _require_keys(raw, {"seed", "device", "dataset", "model", "training"}, "config")
    if not isinstance(raw["seed"], int):
        raise ValueError("seed must be an integer")
    if not isinstance(raw["device"], str):
        raise ValueError("device must be a string")
    return ExperimentConfig(
        seed=raw["seed"],
        device=raw["device"],
        dataset=_parse_dataset(raw["dataset"]),
        model=_parse_model(raw["model"]),
        training=_parse_training(raw["training"]),
    )


def _parse_dataset(value: Any) -> DatasetConfig:
    if not isinstance(value, dict):
        raise ValueError("dataset must be a mapping")
    allowed = {
        "name",
        "root",
        "image_size",
        "context_views",
        "target_views",
        "length",
        "sample_stride",
    }
    _reject_unknown(value, allowed, "dataset")
    _require_keys(
        value, {"name", "root", "image_size", "context_views", "target_views", "length"}, "dataset"
    )
    name = value["name"]
    if name not in {"synthetic", "manifest", "replica", "hypersim"}:
        raise ValueError("dataset.name must be synthetic, manifest, replica, or hypersim")
    root = value["root"]
    if root is not None and not isinstance(root, str):
        raise ValueError("dataset.root must be a string or null")
    if name != "synthetic" and not root:
        raise ValueError("prepared real datasets require dataset.root")
    image_size = _parse_image_size(value["image_size"])
    context_views = _positive_int(value["context_views"], "dataset.context_views")
    target_views = _positive_int(value["target_views"], "dataset.target_views")
    length = _positive_int(value["length"], "dataset.length")
    sample_stride = _positive_int(value.get("sample_stride", 1), "dataset.sample_stride")
    return DatasetConfig(name, root, image_size, context_views, target_views, length, sample_stride)


def _parse_model(value: Any) -> ModelConfig:
    if not isinstance(value, dict):
        raise ValueError("model must be a mapping")
    allowed = {
        "mode",
        "voxel_resolution",
        "image_feature_dim",
        "state_feature_dim",
        "refinement_blocks",
        "n_samples",
        "ray_chunk_size",
    }
    _reject_unknown(value, allowed, "model")
    _require_keys(value, allowed, "model")
    try:
        return ModelConfig(**value)
    except (TypeError, ValueError) as error:
        raise ValueError(f"invalid model config: {error}") from error


def _parse_training(value: Any) -> TrainingConfig:
    if not isinstance(value, dict):
        raise ValueError("training must be a mapping")
    allowed = {
        "output_dir",
        "batch_size",
        "learning_rate",
        "max_steps",
        "num_workers",
        "amp",
        "log_every",
        "checkpoint_every",
        "measurements",
        "gradient_accumulation",
        "weight_decay",
        "resume",
    }
    required = {
        "output_dir",
        "batch_size",
        "learning_rate",
        "max_steps",
        "num_workers",
        "amp",
        "log_every",
        "checkpoint_every",
        "measurements",
    }
    _reject_unknown(value, allowed, "training")
    _require_keys(value, required, "training")
    if not isinstance(value["output_dir"], str) or not value["output_dir"]:
        raise ValueError("training.output_dir must be a non-empty string")
    if not isinstance(value["learning_rate"], (int, float)) or value["learning_rate"] <= 0:
        raise ValueError("training.learning_rate must be positive")
    if not isinstance(value["amp"], bool):
        raise ValueError("training.amp must be boolean")
    if not isinstance(value["measurements"], list) or not all(
        isinstance(name, str) for name in value["measurements"]
    ):
        raise ValueError("training.measurements must be a list of strings")
    resume = value.get("resume")
    if resume is not None and not isinstance(resume, str):
        raise ValueError("training.resume must be a string or null")
    return TrainingConfig(
        output_dir=value["output_dir"],
        batch_size=_positive_int(value["batch_size"], "training.batch_size"),
        learning_rate=float(value["learning_rate"]),
        max_steps=_positive_int(value["max_steps"], "training.max_steps"),
        num_workers=_nonnegative_int(value["num_workers"], "training.num_workers"),
        amp=value["amp"],
        log_every=_positive_int(value["log_every"], "training.log_every"),
        checkpoint_every=_positive_int(value["checkpoint_every"], "training.checkpoint_every"),
        measurements=tuple(value["measurements"]),
        gradient_accumulation=_positive_int(
            value.get("gradient_accumulation", 1), "training.gradient_accumulation"
        ),
        weight_decay=float(value.get("weight_decay", 0.0)),
        resume=resume,
    )


def _parse_image_size(value: Any) -> tuple[int, int]:
    if not isinstance(value, list) or len(value) != 2:
        raise ValueError("dataset.image_size must be [height, width]")
    return (
        _positive_int(value[0], "dataset.image_size[0]"),
        _positive_int(value[1], "dataset.image_size[1]"),
    )


def _positive_int(value: Any, name: str) -> int:
    if not isinstance(value, int) or value < 1:
        raise ValueError(f"{name} must be a positive integer")
    return value


def _nonnegative_int(value: Any, name: str) -> int:
    if not isinstance(value, int) or value < 0:
        raise ValueError(f"{name} must be a non-negative integer")
    return value


def _reject_unknown(value: dict[str, Any], allowed: set[str], name: str) -> None:
    unknown = set(value) - allowed
    if unknown:
        raise ValueError(f"unknown {name} keys: {sorted(unknown)}")


def _require_keys(value: dict[str, Any], required: set[str], name: str) -> None:
    missing = required - set(value)
    if missing:
        raise ValueError(f"missing {name} keys: {sorted(missing)}")
