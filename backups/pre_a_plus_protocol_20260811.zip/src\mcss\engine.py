"""Reproducible training and evaluation engine for scene-state experiments."""

from __future__ import annotations

import json
import math
import os
import random
from collections.abc import Iterator
from dataclasses import asdict
from pathlib import Path

import numpy as np
import torch
from torch import Tensor
from torch.optim import AdamW
from torch.utils.data import DataLoader, Dataset

from mcss.config import DatasetConfig, ExperimentConfig
from mcss.data.collate import collate_scene_examples
from mcss.data.manifest_dataset import ManifestSceneDataset
from mcss.data.synthetic import SyntheticSceneDataset
from mcss.losses import MeasurementLoss
from mcss.metrics import compute_metrics
from mcss.model.system import MeasurementCompleteSystem, build_model
from mcss.types import SceneBatch, SceneExample

DEFAULT_LOSS_WEIGHTS = {
    "rgb": 1.0,
    "depth": 1.0,
    "normal": 0.5,
    "point": 0.25,
    "visibility": 0.5,
    "uncertainty": 0.1,
}


class Trainer:
    """Own model, optimizer, data, output artifacts, and deterministic runtime state."""

    def __init__(self, config: ExperimentConfig) -> None:
        self.config = config
        seed_everything(config.seed)
        self.device = resolve_device(config.device)
        self.output_dir = Path(config.training.output_dir)
        self.checkpoint_dir = self.output_dir / "checkpoints"
        self.model: MeasurementCompleteSystem = build_model(config.model).to(self.device)
        self.optimizer = AdamW(
            self.model.parameters(),
            lr=config.training.learning_rate,
            weight_decay=config.training.weight_decay,
        )
        self.amp_enabled = config.training.amp and self.device.type == "cuda"
        self.scaler = torch.amp.GradScaler("cuda", enabled=self.amp_enabled)
        weights = {
            name: DEFAULT_LOSS_WEIGHTS.get(name, 1.0) for name in config.training.measurements
        }
        self.objective = MeasurementLoss(weights)
        self.dataset = build_dataset(config.dataset, seed=config.seed)
        self.loader = DataLoader(
            self.dataset,
            batch_size=config.training.batch_size,
            shuffle=True,
            num_workers=config.training.num_workers,
            pin_memory=self.device.type == "cuda",
            collate_fn=collate_scene_examples,
            drop_last=False,
        )
        self.step = 0
        if config.training.resume:
            self.load_checkpoint(config.training.resume, load_optimizer=True)

    def train(self) -> Path:
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        _atomic_json(self.output_dir / "resolved_config.json", asdict(self.config))
        self.model.train()
        batches = _cycle(self.loader)
        self.optimizer.zero_grad(set_to_none=True)
        latest_checkpoint = self._checkpoint_path(self.step)
        for step in range(self.step + 1, self.config.training.max_steps + 1):
            batch = next(batches).to(self.device)
            with torch.autocast(device_type=self.device.type, enabled=self.amp_enabled):
                output = self.model(
                    batch.context_rgb, batch.context_cameras, batch.target_cameras, batch.bounds
                )
                predictions = output.predictions
                targets = batch.targets()
                loss, terms = self.objective(predictions, targets)
                regularization = _state_regularization(output.state.density_logits)
                total = (loss + regularization) / self.config.training.gradient_accumulation
            self.scaler.scale(total).backward()
            if step % self.config.training.gradient_accumulation == 0:
                self.scaler.unscale_(self.optimizer)
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
                self.scaler.step(self.optimizer)
                self.scaler.update()
                self.optimizer.zero_grad(set_to_none=True)
            self.step = step
            if step % self.config.training.log_every == 0:
                _append_jsonl(
                    self.output_dir / "train.jsonl",
                    {
                        "step": step,
                        "loss": float(loss.detach().item()),
                        "regularization": float(regularization.detach().item()),
                        **{
                            f"loss/{name}": float(value.detach().item())
                            for name, value in terms.items()
                        },
                    },
                )
            if (
                step % self.config.training.checkpoint_every == 0
                or step == self.config.training.max_steps
            ):
                latest_checkpoint = self.save_checkpoint()
        return latest_checkpoint

    @torch.no_grad()
    def evaluate(self, checkpoint: str | Path | None = None) -> dict[str, float]:
        if checkpoint is not None:
            self.load_checkpoint(checkpoint, load_optimizer=False)
        self.model.eval()
        totals: dict[str, float] = {}
        counts: dict[str, int] = {}
        infinite: set[str] = set()
        evaluation_loader = DataLoader(
            self.dataset,
            batch_size=self.config.training.batch_size,
            shuffle=False,
            num_workers=self.config.training.num_workers,
            collate_fn=collate_scene_examples,
        )
        for batch in evaluation_loader:
            batch = batch.to(self.device)
            output = self.model(
                batch.context_rgb, batch.context_cameras, batch.target_cameras, batch.bounds
            )
            metrics = compute_metrics(output.predictions, batch.targets())
            for name, value in metrics.items():
                if math.isinf(value):
                    infinite.add(name)
                elif math.isfinite(value):
                    totals[name] = totals.get(name, 0.0) + value
                    counts[name] = counts.get(name, 0) + 1
        results = {
            name: (float("inf") if name in infinite else totals[name] / counts[name])
            for name in set(totals) | infinite
        }
        self.output_dir.mkdir(parents=True, exist_ok=True)
        _atomic_json(self.output_dir / "evaluation.json", results)
        return results

    def save_checkpoint(self) -> Path:
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        path = self._checkpoint_path(self.step)
        temporary = path.with_name(path.name + ".part")
        payload = {
            "step": self.step,
            "config": asdict(self.config),
            "model": self.model.state_dict(),
            "optimizer": self.optimizer.state_dict(),
            "scaler": self.scaler.state_dict(),
            "random_state": _random_state(),
        }
        torch.save(payload, temporary)
        os.replace(temporary, path)
        return path

    def load_checkpoint(self, path: str | Path, *, load_optimizer: bool) -> None:
        checkpoint_path = Path(path)
        if not checkpoint_path.is_file():
            raise FileNotFoundError(checkpoint_path)
        payload = torch.load(checkpoint_path, map_location=self.device, weights_only=False)
        self.model.load_state_dict(payload["model"])
        self.step = int(payload.get("step", 0))
        if load_optimizer:
            self.optimizer.load_state_dict(payload["optimizer"])
            if "scaler" in payload:
                self.scaler.load_state_dict(payload["scaler"])
            if "random_state" in payload:
                _restore_random_state(payload["random_state"])

    def _checkpoint_path(self, step: int) -> Path:
        return self.checkpoint_dir / f"step_{step:06d}.pt"


def build_dataset(config: DatasetConfig, *, seed: int) -> Dataset[SceneExample]:
    if config.name == "synthetic":
        return SyntheticSceneDataset(
            length=config.length,
            image_size=config.image_size,
            context_views=config.context_views,
            target_views=config.target_views,
            seed=seed,
        )
    if config.root is None:
        raise ValueError("real datasets require a prepared manifest root")
    return ManifestSceneDataset(
        config.root,
        context_views=config.context_views,
        target_views=config.target_views,
        image_size=config.image_size,
        sample_stride=config.sample_stride,
    )


def resolve_device(requested: str) -> torch.device:
    if requested == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    device = torch.device(requested)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is not available")
    return device


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def _cycle(loader: DataLoader[SceneBatch]) -> Iterator[SceneBatch]:
    while True:
        yield from loader


def _state_regularization(density_logits: Tensor) -> Tensor:
    density = torch.nn.functional.softplus(density_logits)
    sparsity = density.mean() * 1e-4
    differences = [
        (density[..., 1:] - density[..., :-1]).abs().mean(),
        (density[:, :, :, 1:, :] - density[:, :, :, :-1, :]).abs().mean(),
        (density[:, :, 1:, :, :] - density[:, :, :-1, :, :]).abs().mean(),
    ]
    return sparsity + 1e-5 * sum(differences)


def _append_jsonl(path: Path, record: dict[str, float | int]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, sort_keys=True) + "\n")


def _atomic_json(path: Path, data: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".part")
    temporary.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def _random_state() -> dict[str, object]:
    return {
        "python": random.getstate(),
        "numpy": np.random.get_state(),
        "torch": torch.get_rng_state(),
        "cuda": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None,
    }


def _restore_random_state(state: dict[str, object]) -> None:
    random.setstate(state["python"])  # type: ignore[arg-type]
    np.random.set_state(state["numpy"])  # type: ignore[arg-type]
    torch_state = state["torch"]
    if not isinstance(torch_state, Tensor):
        raise TypeError("torch RNG state must be a tensor")
    torch.set_rng_state(torch_state.detach().cpu().to(dtype=torch.uint8))
    if state.get("cuda") is not None and torch.cuda.is_available():
        cuda_states = state["cuda"]
        if not isinstance(cuda_states, (list, tuple)) or not all(
            isinstance(cuda_state, Tensor) for cuda_state in cuda_states
        ):
            raise TypeError("CUDA RNG state must be a sequence of tensors")
        torch.cuda.set_rng_state_all(
            [cuda_state.detach().cpu().to(dtype=torch.uint8) for cuda_state in cuda_states]
        )
