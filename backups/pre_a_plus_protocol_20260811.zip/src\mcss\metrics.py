"""Standard RGB, geometry, point-map, and visibility metrics."""

from __future__ import annotations

import math
from collections.abc import Mapping

import torch
import torch.nn.functional as functional
from torch import Tensor


def compute_metrics(
    predictions: Mapping[str, Tensor], targets: Mapping[str, Tensor]
) -> dict[str, float]:
    metrics: dict[str, float] = {}
    if "rgb" in predictions and "rgb" in targets:
        metrics.update(_rgb_metrics(predictions["rgb"], targets["rgb"]))
    if "depth" in predictions and "depth" in targets:
        metrics.update(_depth_metrics(predictions["depth"], targets["depth"]))
    if "normal" in predictions and "normal" in targets:
        metrics.update(_normal_metrics(predictions["normal"], targets["normal"]))
    if "point" in predictions and "point" in targets:
        metrics.update(
            _point_metrics(predictions["point"], targets["point"], targets.get("visibility"))
        )
    if "visibility" in predictions and "visibility" in targets:
        metrics.update(_visibility_metrics(predictions["visibility"], targets["visibility"]))
    return metrics


def _rgb_metrics(prediction: Tensor, target: Tensor) -> dict[str, float]:
    mse = (prediction - target).square().mean().item()
    psnr = float("inf") if mse == 0.0 else -10.0 * math.log10(max(mse, 1e-12))
    mean_x, mean_y = prediction.mean().item(), target.mean().item()
    variance_x, variance_y = (
        prediction.var(unbiased=False).item(),
        target.var(unbiased=False).item(),
    )
    covariance = ((prediction - mean_x) * (target - mean_y)).mean().item()
    c1, c2 = 0.01**2, 0.03**2
    ssim = ((2 * mean_x * mean_y + c1) * (2 * covariance + c2)) / (
        (mean_x**2 + mean_y**2 + c1) * (variance_x + variance_y + c2)
    )
    return {"rgb/psnr": psnr, "rgb/ssim": float(ssim), "rgb/mse": mse}


def _depth_metrics(prediction: Tensor, target: Tensor) -> dict[str, float]:
    valid = torch.isfinite(target) & (target > 0)
    if not valid.any():
        return {
            "depth/abs_rel": float("nan"),
            "depth/rmse": float("nan"),
            "depth/delta1": float("nan"),
        }
    error = (prediction - target).abs()
    abs_rel = _masked_mean(error / target.abs().clamp_min(1e-8), valid)
    rmse = _masked_mean((prediction - target).square(), valid).sqrt()
    ratio = torch.maximum(
        prediction.clamp_min(1e-8) / target.clamp_min(1e-8),
        target.clamp_min(1e-8) / prediction.clamp_min(1e-8),
    )
    delta1 = _masked_mean((ratio < 1.25).to(target.dtype), valid)
    return {
        "depth/abs_rel": float(abs_rel.item()),
        "depth/rmse": float(rmse.item()),
        "depth/delta1": float(delta1.item()),
    }


def _normal_metrics(prediction: Tensor, target: Tensor) -> dict[str, float]:
    prediction = functional.normalize(prediction, dim=-3, eps=1e-8)
    target = functional.normalize(target, dim=-3, eps=1e-8)
    valid = target.square().sum(dim=-3, keepdim=True) > 1e-8
    cosine = (prediction * target).sum(dim=-3, keepdim=True).clamp(-1.0, 1.0)
    angle = torch.rad2deg(torch.acos(cosine))
    return {
        "normal/mean_angle": float(_masked_mean(angle, valid).item()),
        "normal/acc_5": float(_masked_mean((angle < 5.0).to(target.dtype), valid).item()),
        "normal/acc_11.25": float(_masked_mean((angle < 11.25).to(target.dtype), valid).item()),
        "normal/acc_22.5": float(_masked_mean((angle < 22.5).to(target.dtype), valid).item()),
    }


def _point_metrics(
    prediction: Tensor, target: Tensor, visibility: Tensor | None
) -> dict[str, float]:
    pred_points = prediction.permute(0, 1, 3, 4, 2).reshape(-1, 3)
    target_points = target.permute(0, 1, 3, 4, 2).reshape(-1, 3)
    valid = torch.isfinite(target_points).all(dim=-1)
    if visibility is not None:
        valid = valid & (visibility.permute(0, 1, 3, 4, 2).reshape(-1) > 0.5)
    pred_points = pred_points[valid]
    target_points = target_points[valid]
    if not len(pred_points) or not len(target_points):
        return {"point/chamfer": float("nan"), "point/fscore_0.05": float("nan")}
    max_points = 2048
    pred_points = pred_points[:max_points]
    target_points = target_points[:max_points]
    distances = torch.cdist(pred_points, target_points)
    pred_to_target = distances.min(dim=1).values
    target_to_pred = distances.min(dim=0).values
    threshold = 0.05
    precision = (pred_to_target < threshold).float().mean()
    recall = (target_to_pred < threshold).float().mean()
    fscore = 2 * precision * recall / (precision + recall).clamp_min(1e-8)
    return {
        "point/chamfer": float(
            (pred_to_target.square().mean() + target_to_pred.square().mean()).item()
        ),
        "point/fscore_0.05": float(fscore.item()),
    }


def _visibility_metrics(prediction: Tensor, target: Tensor) -> dict[str, float]:
    pred = prediction > 0.5
    truth = target > 0.5
    valid = torch.isfinite(target)
    true_positive = (pred & truth & valid).sum().item()
    false_positive = (pred & ~truth & valid).sum().item()
    false_negative = (~pred & truth & valid).sum().item()
    union = true_positive + false_positive + false_negative
    iou = 1.0 if union == 0 else true_positive / union
    f1_denominator = 2 * true_positive + false_positive + false_negative
    f1 = 1.0 if f1_denominator == 0 else (2 * true_positive) / f1_denominator
    return {"visibility/iou": float(iou), "visibility/f1": float(f1)}


def _masked_mean(value: Tensor, mask: Tensor) -> Tensor:
    mask = mask.to(value.dtype)
    while mask.ndim < value.ndim:
        mask = mask.unsqueeze(-3)
    return (value * mask).sum() / mask.sum().clamp_min(1.0)
