from pathlib import Path

import torch

from mcss.cli import main
from mcss.engine import _random_state, _restore_random_state


def _write_config(path: Path, output_dir: Path) -> None:
    path.write_text(
        f"""
seed: 3
device: cpu
dataset:
  name: synthetic
  root: null
  image_size: [8, 8]
  context_views: 2
  target_views: 1
  length: 2
model:
  mode: fixed
  voxel_resolution: 8
  image_feature_dim: 8
  state_feature_dim: 8
  refinement_blocks: 1
  n_samples: 8
  ray_chunk_size: 128
training:
  output_dir: {output_dir.as_posix()}
  batch_size: 1
  learning_rate: 0.001
  max_steps: 1
  num_workers: 0
  amp: false
  log_every: 1
  checkpoint_every: 1
  measurements: [rgb, depth, normal, point, visibility]
""".strip(),
        encoding="utf-8",
    )


def test_cli_trains_and_evaluates_synthetic_smoke(tmp_path: Path) -> None:
    config_path = tmp_path / "smoke.yaml"
    output_dir = tmp_path / "outputs"
    _write_config(config_path, output_dir)

    assert main(["train", "--config", str(config_path)]) == 0
    checkpoint = output_dir / "checkpoints" / "step_000001.pt"
    assert checkpoint.is_file()
    assert (output_dir / "train.jsonl").is_file()

    assert main(["evaluate", "--config", str(config_path), "--checkpoint", str(checkpoint)]) == 0
    assert (output_dir / "evaluation.json").is_file()


def test_cli_download_dry_run_does_not_create_data_root(tmp_path: Path) -> None:
    root = tmp_path / "hypersim"

    assert (
        main(
            [
                "download",
                "hypersim",
                "--root",
                str(root),
                "--scenes",
                "ai_001_001",
                "--dry-run",
            ]
        )
        == 0
    )
    assert not root.exists()


def test_restore_random_state_accepts_cuda_mapped_cpu_rng_state() -> None:
    if not torch.cuda.is_available():
        return
    state = _random_state()
    state["torch"] = state["torch"].to("cuda")
    state["cuda"] = [cuda_state.to("cuda") for cuda_state in state["cuda"]]

    _restore_random_state(state)
