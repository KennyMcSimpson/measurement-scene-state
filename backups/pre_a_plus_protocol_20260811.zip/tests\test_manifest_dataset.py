from pathlib import Path

import numpy as np
from PIL import Image

from mcss.data.manifest import ManifestFrame, SceneManifest, save_manifest
from mcss.data.manifest_dataset import ManifestSceneDataset


def test_manifest_dataset_loads_and_resizes_modalities(tmp_path: Path) -> None:
    scene = tmp_path / "scene"
    (scene / "rgb").mkdir(parents=True)
    (scene / "depth").mkdir()
    (scene / "normal").mkdir()
    for index in range(3):
        Image.new("RGB", (4, 4), (20 + index, 30, 40)).save(scene / "rgb" / f"{index:06d}.png")
        np.save(scene / "depth" / f"{index:06d}.npy", np.full((4, 4), 2.0, dtype=np.float32))
        normal = np.zeros((4, 4, 3), dtype=np.float32)
        normal[..., 2] = 1.0
        np.save(scene / "normal" / f"{index:06d}.npy", normal)
    frames = tuple(
        ManifestFrame(
            frame_id=index,
            rgb=f"rgb/{index:06d}.png",
            intrinsics=[[4.0, 0.0, 1.5], [0.0, 4.0, 1.5], [0.0, 0.0, 1.0]],
            c2w=np.eye(4).tolist(),
            depth=f"depth/{index:06d}.npy",
            normal=f"normal/{index:06d}.npy",
        )
        for index in range(3)
    )
    save_manifest(
        SceneManifest("scene", (4, 4), ((-1.0, -1.0, -1.0), (1.0, 1.0, 1.0)), frames, scene),
        scene / "manifest.json",
    )

    dataset = ManifestSceneDataset(scene, context_views=2, target_views=1, image_size=(2, 2))
    example = dataset[0]

    assert example.context_rgb.shape == (2, 3, 2, 2)
    assert example.target_depth.shape == (1, 1, 2, 2)
    assert example.target_normal.shape == (1, 3, 2, 2)
    assert example.target_point.shape == (1, 3, 2, 2)
    assert example.target_visibility.all()
    assert example.target_cameras.intrinsics[0, 0, 0] == 2.0
    assert example.target_cameras.intrinsics[0, 0, 2] == 0.75
