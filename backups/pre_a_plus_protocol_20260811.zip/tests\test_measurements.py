import torch

from mcss.geometry import look_at, make_intrinsics, make_voxel_centers
from mcss.measurements import FixedMeasurementRenderer
from mcss.types import Cameras, SceneState


def _sphere_state(resolution: int = 12) -> SceneState:
    bounds = torch.tensor([[[-1.0, -1.0, -1.0], [1.0, 1.0, 1.0]]])
    points = make_voxel_centers(bounds, resolution)
    radius = torch.linalg.vector_norm(points, dim=-1)
    density = (12.0 * (0.65 - radius)).unsqueeze(1).requires_grad_()
    color = torch.zeros(1, 3, resolution, resolution, resolution)
    color[:, 0] = 0.8
    color[:, 1] = 0.2
    color[:, 2] = 0.1
    log_variance = torch.full_like(density, -3.0)
    return SceneState(density, color, log_variance, bounds)


def _cameras() -> Cameras:
    intrinsics = make_intrinsics((8, 8), 55.0).view(1, 1, 3, 3)
    c2w = look_at(torch.tensor([0.0, 0.0, -3.0]), torch.zeros(3)).view(1, 1, 4, 4)
    return Cameras(intrinsics, c2w, (8, 8))


def test_fixed_renderer_is_parameter_free_and_differentiable() -> None:
    renderer = FixedMeasurementRenderer(n_samples=24, ray_chunk_size=31)
    state = _sphere_state()

    outputs = renderer(state, _cameras())

    assert sum(parameter.numel() for parameter in renderer.parameters()) == 0
    assert set(outputs) == {"depth", "normal", "point", "rgb", "uncertainty", "visibility"}
    assert outputs["rgb"].shape == (1, 1, 3, 8, 8)
    assert outputs["depth"].shape == (1, 1, 1, 8, 8)
    assert all(torch.isfinite(value).all() for value in outputs.values())

    outputs["depth"].mean().backward()
    assert state.density_logits.grad is not None
    assert torch.isfinite(state.density_logits.grad).all()


def test_measurement_selection_and_query_permutation_are_exact() -> None:
    renderer = FixedMeasurementRenderer(n_samples=16, ray_chunk_size=64)
    state = _sphere_state(10)
    camera = _cameras()
    second_pose = look_at(torch.tensor([2.5, 0.0, -1.5]), torch.zeros(3))
    cameras = Cameras(
        camera.intrinsics.expand(1, 2, 3, 3).clone(),
        torch.stack((camera.c2w[0, 0], second_pose), dim=0).unsqueeze(0),
        camera.image_size,
    )

    reference = renderer(state, cameras, {"depth", "visibility"})
    permuted = renderer(state, cameras.select_views(torch.tensor([1, 0])), {"depth", "visibility"})

    assert set(reference) == {"depth", "visibility"}
    torch.testing.assert_close(reference["depth"][:, [1, 0]], permuted["depth"])
    torch.testing.assert_close(reference["visibility"][:, [1, 0]], permuted["visibility"])
