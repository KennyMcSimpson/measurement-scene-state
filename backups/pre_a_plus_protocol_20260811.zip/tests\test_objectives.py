import math

import torch

from mcss.losses import MeasurementLoss
from mcss.metrics import compute_metrics


def _targets() -> dict[str, torch.Tensor]:
    return {
        "rgb": torch.full((1, 1, 3, 4, 4), 0.5),
        "depth": torch.full((1, 1, 1, 4, 4), 2.0),
        "normal": torch.tensor([0.0, 0.0, 1.0]).view(1, 1, 3, 1, 1).expand(1, 1, 3, 4, 4),
        "point": torch.zeros(1, 1, 3, 4, 4),
        "visibility": torch.ones(1, 1, 1, 4, 4),
        "uncertainty": torch.full((1, 1, 1, 4, 4), 0.1),
    }


def test_perfect_predictions_have_zero_geometry_error() -> None:
    targets = _targets()
    metrics = compute_metrics(targets, targets)

    assert math.isinf(metrics["rgb/psnr"])
    assert metrics["depth/abs_rel"] == 0.0
    assert metrics["depth/rmse"] == 0.0
    assert metrics["depth/delta1"] == 1.0
    assert metrics["normal/mean_angle"] < 0.03
    assert metrics["visibility/iou"] == 1.0
    assert metrics["visibility/f1"] == 1.0


def test_measurement_loss_masks_invalid_depth_and_is_differentiable() -> None:
    targets = _targets()
    targets["depth"][..., 0, 0] = 0.0
    predictions = {name: value.clone().requires_grad_(True) for name, value in targets.items()}
    predictions["depth"].data[..., 0, 0] = 100.0
    objective = MeasurementLoss({"rgb": 1.0, "depth": 1.0, "normal": 1.0, "visibility": 1.0})

    loss, terms = objective(predictions, targets)

    assert terms["depth"] == 0.0
    loss.backward()
    assert predictions["depth"].grad is not None


def test_visibility_loss_is_safe_inside_cuda_autocast() -> None:
    if not torch.cuda.is_available():
        return
    prediction = torch.full((1, 1, 1, 2, 2), 0.75, device="cuda", requires_grad=True)
    target = torch.ones_like(prediction)
    objective = MeasurementLoss({"visibility": 1.0})

    with torch.autocast(device_type="cuda", enabled=True):
        loss, terms = objective({"visibility": prediction}, {"visibility": target})
    loss.backward()

    assert torch.isfinite(loss)
    assert torch.isfinite(terms["visibility"])
    assert prediction.grad is not None
