# Experimental Protocol

## Main setting

- Static, calibrated sparse-view reconstruction.
- Context is 2 or 4 RGB images; target RGB is withheld at inference.
- Target queries use known intrinsics and camera-to-world matrices.
- The main A+ state is anchored to the first preselected context camera and uses fixed metric
  local bounds from the experiment config.
- Main outputs are metric ray depth, anchor-frame normal, anchor-frame point map, and local
  visibility. RGB is auxiliary and is reported separately.

## Spatial protocol

`context_local_metric` is the main protocol. Context and target cameras are rigidly expressed in
the first context camera frame. The anchor is chosen before target labels are loaded. The fixed
local bounds determine state extent, voxel spacing, ray sampling, and the query-only support mask.
Target RGB, depth, normal, point, visibility, and manifest bounds cannot affect those choices.

Target depth or point labels are used only after the query and support are fixed. If the observed
surface lies outside the local state, its local visibility label is zero, geometry labels are
invalidated, and auxiliary RGB uses the renderer background. The query remains in the protocol.
Report both query support coverage and the fraction of locally visible target surfaces so local
cropping cannot be hidden as an accuracy gain.

`legacy_manifest_bounds` is retained for reproducing old pilots and as a privileged/oracle
control. Prepared manifest bounds may contain geometry aggregated from every frame and therefore
cannot be used by the main A+ result.

The Hypersim A+ config uses a `12 x 8 x 12 m` local support and a `[48,32,48]` grid, which gives
`0.25 m` spacing on every axis. A future `24 m` candidate range denotes maximum ray distance, not
a `24 m` cube side length. A+ uses BF16 autocast on supported CUDA devices because the density-
gradient normal path can overflow FP16 dynamic loss scaling on nearly flat initial states.

## Measurement-complete claim

Define a training measurement set `M_train` and an evaluation set `M_eval`. A measurement
generalization matrix reports every pair. The key row trains the same fixed state with RGB/depth
and evaluates normal, point, and visibility without adding a target-specific head. Report the
held-out gap against a seen measurement and the corresponding controls.

The primary controls are:

1. `fixed`: explicit state plus parameter-free renderer.
2. `learned_heads`: same context encoder/state capacity, separate learned per-measurement heads.
3. `free_decoder`: same state features plus query origin/direction and a shared learned decoder.

External references such as SRT/OSRT, pixelNeRF, pixelSplat, MVSplat, DUSt3R, MASt3R, VGGT, and
per-scene 3DGS must be rerun or evaluated under exactly the same split, context count, camera
inputs, image resolution, query frames, and metric implementation. Original paper numbers are
not directly comparable to this protocol.

## Metrics

- RGB: PSNR, SSIM, optional LPIPS.
- Depth: AbsRel, RMSE, delta-1.
- Normal: mean angular error and 5/11.25/22.5 degree accuracy.
- Point map: direct metric MAE/RMSE, support-diagonal normalized RMSE, symmetric Chamfer, and
  F-score at 0.05/0.25/0.50 m. With a 0.25 m grid, 0.25 m is the resolution-matched primary
  threshold; 0.05 m is a strict diagnostic.
- Visibility: IoU and F1.

Each metric must include valid-pixel or valid-point counts and query support coverage. Missing
modalities are not silently treated as zeros.

## Mechanism diagnostics

- Cross-context consistency: compare predictions from two context subsets on identical queries.
- Query permutation: permute target camera order and require output equivariance.
- Intervention specificity: alter density or color fields separately and measure intended versus
  cross-task changes.
- No-bypass audit: fixed renderer parameter count is zero and model forward exposes no target
  labels.
- Uncertainty calibration: bin predicted variance and compare coverage/error when uncertainty is
  enabled.

These diagnostics establish inspectable mechanisms; they do not make arbitrary latent channels
human-interpretable.

## Leakage controls

Do not choose context frames after looking at target RGB/depth. Keep scenes disjoint across train,
validation, and test. Do not use target depth or full-scene manifest bounds to choose the anchor,
state bounds, coordinate normalization, voxel resolution, ray samples, or query support. Report
per-scene and pooled metrics, both support coverages, frame timing, state voxel resolution and
metric spacing, number of ray samples, and peak GPU memory.
