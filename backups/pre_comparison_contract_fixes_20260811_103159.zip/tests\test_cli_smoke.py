import json
import math
from pathlib import Path

import pytest
import torch

from mcss.cli import main
from mcss.engine import (
    _random_state,
    _restore_random_state,
    _ScalarTracker,
    _scheduled_learning_rate,
)


def _write_config(
    path: Path,
    output_dir: Path,
    *,
    device: str = "cpu",
    amp: bool = False,
    amp_dtype: str = "float16",
) -> None:
    path.write_text(
        f"""
seed: 3
device: {device}
dataset:
  name: synthetic
  root: null
  image_size: [8, 8]
  context_views: 2
  target_views: 1
  length: 2
model:
  mode: fixed
  voxel_resolution: 8
  image_feature_dim: 8
  state_feature_dim: 8
  refinement_blocks: 1
  n_samples: 8
  ray_chunk_size: 128
training:
  output_dir: {output_dir.as_posix()}
  batch_size: 1
  learning_rate: 0.001
  max_steps: 1
  num_workers: 0
  amp: {str(amp).lower()}
  amp_dtype: {amp_dtype}
  log_every: 1
  checkpoint_every: 1
  measurements: [rgb, depth, normal, point, visibility]
  lr_schedule: warmup_cosine
  warmup_steps: 1
  min_lr_ratio: 0.1
  ema_decay: 0.9
""".strip(),
        encoding="utf-8",
    )


def test_cli_trains_and_evaluates_synthetic_smoke(tmp_path: Path) -> None:
    config_path = tmp_path / "smoke.yaml"
    output_dir = tmp_path / "outputs"
    _write_config(config_path, output_dir)

    assert main(["train", "--config", str(config_path)]) == 0
    checkpoint = output_dir / "checkpoints" / "step_000001.pt"
    assert checkpoint.is_file()
    assert (output_dir / "train.jsonl").is_file()
    record = json.loads((output_dir / "train.jsonl").read_text(encoding="utf-8").splitlines()[-1])
    expected_fields = {
        "step",
        "epoch",
        "epoch_progress",
        "batch_in_epoch",
        "batches_per_epoch",
        "lr",
        "grad/norm",
        "amp/scale",
        "optimizer/step",
        "optimizer/updated",
        "optimizer/skipped",
        "loss",
        "window/loss",
        "ema/loss",
        "time/step_seconds",
        "scene_ids",
        "valid/support",
        "valid/depth",
    }
    assert expected_fields <= set(record)
    assert record["optimizer/updated"] is True
    assert record["optimizer/skipped"] is False
    assert record["scene_ids"][0].startswith("synthetic_")
    payload = torch.load(checkpoint, map_location="cpu", weights_only=False)
    assert payload["optimizer_step"] == 1
    assert "telemetry" in payload

    assert main(["evaluate", "--config", str(config_path), "--checkpoint", str(checkpoint)]) == 0
    assert (output_dir / "evaluation.json").is_file()


def test_cli_download_dry_run_does_not_create_data_root(tmp_path: Path) -> None:
    root = tmp_path / "hypersim"

    assert (
        main(
            [
                "download",
                "hypersim",
                "--root",
                str(root),
                "--scenes",
                "ai_001_001",
                "--dry-run",
            ]
        )
        == 0
    )
    assert not root.exists()


def test_restore_random_state_accepts_cuda_mapped_cpu_rng_state() -> None:
    if not torch.cuda.is_available():
        return
    state = _random_state()
    state["torch"] = state["torch"].to("cuda")
    state["cuda"] = [cuda_state.to("cuda") for cuda_state in state["cuda"]]

    _restore_random_state(state)


def test_warmup_cosine_learning_rate_has_explicit_endpoints() -> None:
    base = 1e-3

    assert _scheduled_learning_rate(base, 1, 6, 2, 0.1) == pytest.approx(0.5e-3)
    assert _scheduled_learning_rate(base, 2, 6, 2, 0.1) == pytest.approx(1e-3)
    assert _scheduled_learning_rate(base, 4, 6, 2, 0.1) == pytest.approx(0.55e-3)
    assert _scheduled_learning_rate(base, 6, 6, 2, 0.1) == pytest.approx(0.1e-3)


def test_scalar_tracker_reports_window_means_and_resume_safe_ema() -> None:
    tracker = _ScalarTracker(ema_decay=0.5)
    tracker.update({"loss": 2.0, "loss/depth": 1.0})
    tracker.update({"loss": 4.0, "loss/depth": 3.0})

    first = tracker.snapshot(reset_window=True)
    state = tracker.state_dict()
    resumed = _ScalarTracker(ema_decay=0.5)
    resumed.load_state_dict(state)
    resumed.update({"loss": 6.0, "loss/depth": 5.0})
    second = resumed.snapshot(reset_window=True)

    assert first["window/loss"] == 3.0
    assert first["ema/loss"] == 3.0
    assert first["window/loss/depth"] == 2.0
    assert second["window/loss"] == 6.0
    assert second["ema/loss"] == 4.5


def test_bfloat16_cuda_training_updates_without_scaler_skip(tmp_path: Path) -> None:
    if not torch.cuda.is_available():
        return
    config_path = tmp_path / "cuda_bfloat16.yaml"
    output_dir = tmp_path / "cuda_outputs"
    _write_config(
        config_path,
        output_dir,
        device="cuda",
        amp=True,
        amp_dtype="bfloat16",
    )

    assert main(["train", "--config", str(config_path)]) == 0

    record = json.loads((output_dir / "train.jsonl").read_text(encoding="utf-8"))
    assert record["optimizer/updated"] is True
    assert record["optimizer/skipped"] is False
    assert math.isfinite(record["grad/norm"])
