import pytest
import torch

from mcss.types import Cameras, SceneState


def test_cameras_validate_shape_and_homogeneous_row() -> None:
    intrinsics = torch.eye(3).view(1, 1, 3, 3)
    c2w = torch.eye(4).view(1, 1, 4, 4)
    cameras = Cameras(intrinsics=intrinsics, c2w=c2w, image_size=(8, 10))

    assert cameras.leading_shape == (1, 1)
    assert cameras.image_size == (8, 10)

    invalid = c2w.clone()
    invalid[..., 3, 0] = 1.0
    with pytest.raises(ValueError, match="homogeneous"):
        Cameras(intrinsics=intrinsics, c2w=invalid, image_size=(8, 10))


def test_scene_state_rejects_inconsistent_typed_fields() -> None:
    bounds = torch.tensor([[[-1.0, -1.0, -1.0], [1.0, 1.0, 1.0]]])
    density = torch.zeros(1, 1, 4, 4, 4)
    color = torch.zeros(1, 3, 4, 4, 4)
    variance = torch.zeros(1, 1, 4, 4, 4)

    state = SceneState(density, color, variance, bounds)
    assert state.spatial_shape == (4, 4, 4)

    with pytest.raises(ValueError, match="spatial"):
        SceneState(density, color[..., :-1], variance, bounds)
