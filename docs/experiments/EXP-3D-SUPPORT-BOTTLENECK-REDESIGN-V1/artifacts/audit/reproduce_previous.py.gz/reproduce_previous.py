from pathlib import Path
import hashlib,json
from collections import Counter
import numpy as np
import torch
from mcss.dynamic.checkpoint import load_dynamic_checkpoint
from mcss.mechanism_pilot.static_evaluation import summarize
from mcss.mechanism_pilot.static_geometry import support_audit,summary
from mcss.types import Cameras

ROOT=Path.cwd();OLD=ROOT/'outputs/EXP-3D-STATIC-CARRIER-ATTRIBUTION-V1';OUT=ROOT/'outputs/EXP-3D-SUPPORT-BOTTLENECK-REDESIGN-V1';AUD=OUT/'audit'
def read(p):return json.loads(p.read_text())
def save(p,d):p.write_text(json.dumps(d,indent=2,sort_keys=True,allow_nan=False)+'\n')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1024**2),b''):h.update(chunk)
 return h.hexdigest()
carrierpath=ROOT/'outputs/EXP-3D-20260927-centered-training-1000a-600b-v1/training/phase_b_final.pt'
residualpath=OLD/'residual_30000/best.pt'
files={str(p.relative_to(ROOT)):{'sha256':sha(p),'bytes':p.stat().st_size} for folder in [OLD,ROOT/'docs/experiments/EXP-3D-STATIC-CARRIER-ATTRIBUTION-V1'] for p in folder.rglob('*') if p.is_file()}
files[str(carrierpath.relative_to(ROOT))]={'sha256':sha(carrierpath),'bytes':carrierpath.stat().st_size}
assert sha(carrierpath)==read(OLD/'checkpoint_manifest.json')['carrier']['sha256']
assert sha(residualpath)==read(OLD/'checkpoint_manifest.json')['residual']['sha256']
save(AUD/'previous_artifact_hashes.json',{'scope':'All existing old experiment output+docs files and frozen old carrier. Residual checkpoints included recursively.','files':files,'old_carrier':str(carrierpath),'old_residual':str(residualpath),'old_carrier_sha256':sha(carrierpath),'old_residual_sha256':sha(residualpath)})
carrier,_,meta=load_dynamic_checkpoint(carrierpath)
points=carrier._candidate_points.detach();bounds=carrier._bounds.detach().reshape(2,3)
checks={};details={}
for run,geodir in [('old_static','geometry_audit'),('unseen_static','unseen_geometry_audit')]:
 raw=read(OLD/run/'static_results.json');recomputed=summarize(raw);published=read(OLD/run/'bootstrap_results.json');checks[run+'_all_statistics_exact']=recomputed==published
 save(AUD/(run+'_statistics_recomputed.json'),recomputed)
 details[run]={'raw_rows':len(raw),'scenes':sorted({r['scene_id'] for r in raw}),'methods':sorted({r['method'] for r in raw}),'Residual_A_and_B_included':all(m in {r['method'] for r in raw} for m in ['Residual_A','Residual_B'])}
 lock=read(OLD/run/'lock.json');manifestpath=next(Path(p) for p in lock['input_sha256'] if p.endswith('/manifest.json'));manifest=read(manifestpath)
 support_expected=read(OLD/geodir/'support_audit.json');support_result={}
 for scene in manifest['scenes']:
  cameras={f['frame_id']:Cameras(torch.tensor(f['intrinsics'],dtype=torch.float32),torch.tensor(f['c2w'],dtype=torch.float32),tuple(manifest['image_size'])) for f in scene['frames']}
  anchorid=scene['roles']['context_a'][0];anchor=cameras[anchorid].c2w;groups={k:scene['roles'].get(k,[]) for k in ['context_a','context_b','stream']};groups['anchor']=[anchorid];groups['context_a_plus_stream']=sorted(set(groups['context_a']+groups['stream']));support_result[scene['scene_id']]={}
  for name,ids in groups.items():
   if not ids:continue
   record,_=support_audit(points,bounds,[(fid,cameras[fid]) for fid in ids],anchor)
   support_result[scene['scene_id']][name]={k:record[k] for k in ['at_least_one','at_least_two','histogram']}
 checks[run+'_support_counts_recomputed_from_cameras_exact']=support_result==support_expected
 save(AUD/(run+'_support_recomputed.json'),support_result)
 volume=read(OLD/geodir/'volume_coverage.json');radius=volume['radius_m'];recomputed_volume=[];mismatches=[]
 for row in volume['frames']:
  npzpath=OLD/geodir/f"{row['scene_id']}_{row['frame_id']:04d}_geometry_raw.npz"
  with np.load(npzpath) as arrays:
   outside=arrays['outside_distance_m'];nearest=arrays['nearest_candidate_distance_m'];xyz=torch.from_numpy(arrays['surface_anchor_xyz']);outside_from_xyz=torch.maximum(bounds.double()[0]-xyz,xyz-bounds.double()[1]).clamp_min(0).norm(dim=-1).numpy()
   if not np.array_equal(outside,outside_from_xyz):mismatches.append([row['scene_id'],row['frame_id'],'outside_geometry'])
   derived={'scene_id':row['scene_id'],'frame_id':row['frame_id'],'inside_volume_fraction':float((outside==0).mean()),'outside_distance_m':summary(outside),'nearest_candidate_distance_m':summary(nearest),'any_candidate_neighborhood_fraction':float((nearest<=radius).mean()),'context_supported_neighborhood':{}}
   for key in arrays.files:
    if key.endswith('_nearest_supported_m'):
     role=key[:-len('_nearest_supported_m')];ds=arrays[key];covered=ds<=radius
     derived['context_supported_neighborhood'][role]={'surface_support_fraction':float(covered.mean()),'no_candidate_neighborhood_support_fraction':float((~covered).mean()),'nearest_supported_distance_m':summary(ds)}
   for k,v in derived.items():
    if row[k]!=v:mismatches.append([row['scene_id'],row['frame_id'],k])
   recomputed_volume.append(derived)
 checks[run+'_volume_from_geometry_raw_exact']=not mismatches
 details[run]['volume_frames']=len(recomputed_volume);details[run]['volume_mismatches']=mismatches
 save(AUD/(run+'_volume_recomputed.json'),recomputed_volume)
checks['all_original_hashes_unchanged_after_recompute']=all(sha(ROOT/p)==r['sha256'] for p,r in files.items())
save(AUD/'old_statistics_reproduction.json',{'status':'PASS' if all(checks.values()) else 'FAIL','checks':checks,'details':details,'carrier_sha256':meta['sha256'],'model_inference_calls':0,'DynamicTTT':False,'statistics_unit':'scene','notes':['All static methods including Residual A/B retained; no new predictions.','Support freshly reprojected from dataset cameras and checkpoint geometry.','Volume metrics recomputed from saved GT geometry arrays; outside distances independently recalculated from saved GT surface coordinates.','Nearest-candidate distances reused from archived raw arrays; no new model or neighbor allocation.']})
print(json.dumps({'checks':checks,'files_frozen':len(files),'details':details},indent=2))
